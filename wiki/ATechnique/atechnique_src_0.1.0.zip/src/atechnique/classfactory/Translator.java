package atechnique.classfactory;

import java.util.ArrayList;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import atechnique.views.interfaces.ITranslator;

public class Translator implements ITranslator {
	private Locale _currentLocale;
	private ResourceBundle _messages;

	public Translator(String language, String country) {
        _currentLocale = new Locale(language, country);
        _messages = ResourceBundle.getBundle("atechnique/data/languages/MessagesBundle", _currentLocale);
	}

	@Override
	public ArrayList<String> getTranslatedPhrases(ArrayList<String> translationTags) {
		ArrayList<String> translatedPhrases = new ArrayList<String>();

		if (translationTags != null) {
			for (int idx = 0; idx < translationTags.size(); idx++) {
				try {
					translatedPhrases.add(_messages.getString(translationTags.get(idx)));
				} catch (MissingResourceException e) {
					// Just add the tag surrounded by <>
					translatedPhrases.add("<" + translationTags.get(idx) + ">");				
				}
			}
		}
		
		return translatedPhrases;
	}
}