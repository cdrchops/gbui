package atechnique.models.interfaces;

import atechnique.Campaign;

import java.util.List;

public interface ISelectCampaignModel {
	List<Campaign> getCampaigns();
}
