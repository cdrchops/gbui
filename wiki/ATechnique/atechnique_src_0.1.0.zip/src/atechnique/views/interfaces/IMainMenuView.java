package atechnique.views.interfaces;

public interface IMainMenuView extends IGameStateView {
	void addMainMenuListener(IMainMenuListener mainMenuListener);
}
