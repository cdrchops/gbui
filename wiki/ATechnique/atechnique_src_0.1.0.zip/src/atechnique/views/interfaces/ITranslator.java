package atechnique.views.interfaces;

import java.util.ArrayList;

public interface ITranslator {
	ArrayList<String> getTranslatedPhrases(ArrayList<String> translationTags);
}
